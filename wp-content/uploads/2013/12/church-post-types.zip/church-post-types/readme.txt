=== Plugin Name ===
Contributors: dmorrison42
Tags: sermons, events
Requires at least: 3.0
Tested up to: 3.2
Stable tag: 0.5.1

Plugin for adding sermons and events to wordpress sites.

== Description ==

Plugin for adding sermons and events to wordpress sites. Reqires a theme that handles the sermon post type to work correctly, widgets are included. Note this is an early beta, more documentation to come.
